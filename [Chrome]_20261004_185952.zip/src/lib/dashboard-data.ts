import { db } from "@/db";
import {
  documentReminders,
  garbageSchedules,
  notes,
  systemConfig,
  tasks,
  timetable,
  workLogs,
} from "@/db/schema";
import { asc, desc } from "drizzle-orm";

const seededConfig = [
  { key: "wake_word", value: "Hej Dash" },
  { key: "home_city", value: "Warszawa" },
  { key: "city_lat", value: "52.2297" },
  { key: "city_lon", value: "21.0122" },
  { key: "child_names", value: "Lena, Kuba" },
  { key: "admin_pin", value: process.env.ADMIN_PIN || "2468" },
];

function atLocalTime(daysFromToday: number, hours = 9, minutes = 0) {
  const date = new Date();
  date.setDate(date.getDate() + daysFromToday);
  date.setHours(hours, minutes, 0, 0);
  return date;
}

function dateForIsoDay(isoDay: number, hour: number) {
  const today = new Date();
  const day = today.getDay() || 7;
  const monday = new Date(today);
  monday.setDate(today.getDate() - day + 1);
  monday.setHours(hour, 0, 0, 0);
  monday.setDate(monday.getDate() + isoDay - 1);
  return monday;
}

export async function ensureSeedData() {
  const [existingTasks, existingWork, existingWaste, existingDocs, existingLessons, existingNotes, existingConfig] =
    await Promise.all([
      db.select({ id: tasks.id }).from(tasks).limit(1),
      db.select({ id: workLogs.id }).from(workLogs).limit(1),
      db.select({ id: garbageSchedules.id }).from(garbageSchedules).limit(1),
      db.select({ id: documentReminders.id }).from(documentReminders).limit(1),
      db.select({ id: timetable.id }).from(timetable).limit(1),
      db.select({ id: notes.id }).from(notes).limit(1),
      db.select({ key: systemConfig.key }).from(systemConfig).limit(1),
    ]);

  const inserts: Promise<unknown>[] = [];

  if (existingTasks.length === 0) {
    inserts.push(
      db.insert(tasks).values([
        { title: "Kupić mleko i pieczywo", assignedTo: "Mama", dueDate: atLocalTime(0, 18), isCompleted: false },
        { title: "Odebrać paczkę z paczkomatu", assignedTo: "Tata", dueDate: atLocalTime(0, 17), isCompleted: false },
        { title: "Spakować strój na WF", assignedTo: "Lena", dueDate: atLocalTime(0, 20), isCompleted: true },
        { title: "Podlać zioła na balkonie", assignedTo: "Kuba", dueDate: atLocalTime(1, 19), isCompleted: false },
      ]),
    );
  }

  if (existingWork.length === 0) {
    const today = new Date();
    const weekday = today.getDay() || 7;
    const monday = new Date(today);
    monday.setDate(today.getDate() - weekday + 1);
    monday.setHours(9, 0, 0, 0);
    const hoursByDay = [7.5, 8, 7, 8.5, 7.5];
    const entries = Array.from({ length: Math.min(weekday, 5) }, (_, index) => {
      const date = new Date(monday);
      date.setDate(monday.getDate() + index);
      const hours = index === weekday - 1 ? 8 : hoursByDay[index];
      return { date, hours, note: index === weekday - 1 ? "Projekt HomeDash" : "Praca zdalna" };
    });
    inserts.push(db.insert(workLogs).values(entries));
  }

  if (existingWaste.length === 0) {
    inserts.push(
      db.insert(garbageSchedules).values([
        { fraction: "BIO", pickupDate: atLocalTime(1, 7) },
        { fraction: "PLASTIC_METAL", pickupDate: atLocalTime(3, 7) },
        { fraction: "MIXED", pickupDate: atLocalTime(5, 7) },
        { fraction: "GLASS", pickupDate: atLocalTime(8, 7) },
      ]),
    );
  }

  if (existingDocs.length === 0) {
    inserts.push(
      db.insert(documentReminders).values([
        { title: "Dowód osobisty · Mama", category: "DOKUMENT", expirationDate: atLocalTime(21, 12) },
        { title: "Przegląd samochodu", category: "AUTO", expirationDate: atLocalTime(74, 12) },
        { title: "Ubezpieczenie mieszkania", category: "UBEZPIECZENIE", expirationDate: atLocalTime(162, 12) },
      ]),
    );
  }

  if (existingLessons.length === 0) {
    const subjects = [
      ["08:00", "08:45", "Matematyka"],
      ["08:55", "09:40", "Język polski"],
      ["09:50", "10:35", "Przyroda"],
      ["10:50", "11:35", "Język angielski"],
      ["11:45", "12:30", "Plastyka"],
    ];
    const lessons = ["Lena", "Kuba"].flatMap((childName, childIndex) =>
      [1, 2, 3, 4, 5].flatMap((dayOfWeek) =>
        subjects.slice(0, childIndex === 0 ? 5 : 4).map(([startTime, endTime, subject], index) => ({
          childName,
          dayOfWeek,
          startTime,
          endTime,
          subject: index === 2 && childName === "Kuba" ? "Informatyka" : subject,
          classroom: `${childIndex + 1}${index + 1}`,
        })),
      ),
    );
    inserts.push(db.insert(timetable).values(lessons));
  }

  if (existingNotes.length === 0) {
    inserts.push(
      db.insert(notes).values([
        { title: "Dziś pamiętaj", content: "Po szkole odbiór o 15:30 ✨", color: "violet", isPinned: true },
        { title: "Domowa lista", content: "Baterie AA · cytryny · karma dla Puszka", color: "amber", isPinned: true },
      ]),
    );
  }

  if (existingConfig.length === 0) {
    inserts.push(db.insert(systemConfig).values(seededConfig));
  } else {
    const configRows = await db.select({ key: systemConfig.key }).from(systemConfig);
    const knownKeys = new Set(configRows.map(({ key }) => key));
    const missing = seededConfig.filter(({ key }) => !knownKeys.has(key));
    if (missing.length > 0) inserts.push(db.insert(systemConfig).values(missing));
  }

  await Promise.all(inserts);
}

export async function getDashboardData() {
  await ensureSeedData();
  const [taskRows, workRows, wasteRows, documentRows, lessonRows, noteRows, configRows] = await Promise.all([
    db.select().from(tasks).orderBy(asc(tasks.isCompleted), asc(tasks.dueDate), desc(tasks.createdAt)),
    db.select().from(workLogs).orderBy(desc(workLogs.date)),
    db.select().from(garbageSchedules).orderBy(asc(garbageSchedules.pickupDate)),
    db.select().from(documentReminders).orderBy(asc(documentReminders.expirationDate)),
    db.select().from(timetable).orderBy(asc(timetable.dayOfWeek), asc(timetable.startTime)),
    db.select().from(notes).orderBy(desc(notes.isPinned), desc(notes.createdAt)),
    db.select().from(systemConfig),
  ]);

  return {
    tasks: taskRows,
    workLogs: workRows,
    garbage: wasteRows,
    documents: documentRows,
    timetable: lessonRows,
    notes: noteRows,
    config: Object.fromEntries(configRows.filter(({ key }) => key !== "admin_pin").map(({ key, value }) => [key, value])), 
  };
}
