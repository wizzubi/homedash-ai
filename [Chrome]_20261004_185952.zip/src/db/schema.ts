import {
  boolean,
  integer,
  pgTable,
  real,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";

export const tasks = pgTable("tasks", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: text("title").notNull(),
  assignedTo: text("assignedTo"),
  dueDate: timestamp("dueDate", { withTimezone: true }),
  isCompleted: boolean("isCompleted").notNull().default(false),
  createdAt: timestamp("createdAt", { withTimezone: true }).notNull().defaultNow(),
});

export const workLogs = pgTable("work_logs", {
  id: uuid("id").defaultRandom().primaryKey(),
  date: timestamp("date", { withTimezone: true }).notNull().defaultNow(),
  hours: real("hours").notNull(),
  startTime: text("startTime"),
  endTime: text("endTime"),
  note: text("note"),
  createdAt: timestamp("createdAt", { withTimezone: true }).notNull().defaultNow(),
});

export const garbageSchedules = pgTable("garbage_schedules", {
  id: uuid("id").defaultRandom().primaryKey(),
  fraction: text("fraction").notNull(),
  pickupDate: timestamp("pickupDate", { withTimezone: true }).notNull(),
});

export const documentReminders = pgTable("document_reminders", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: text("title").notNull(),
  expirationDate: timestamp("expirationDate", { withTimezone: true }).notNull(),
  category: text("category").notNull(),
});

export const timetable = pgTable("timetable", {
  id: uuid("id").defaultRandom().primaryKey(),
  childName: text("childName").notNull(),
  dayOfWeek: integer("dayOfWeek").notNull(),
  startTime: text("startTime").notNull(),
  endTime: text("endTime").notNull(),
  subject: text("subject").notNull(),
  classroom: text("classroom"),
});

export const notes = pgTable("notes", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: text("title"),
  content: text("content").notNull(),
  color: text("color").notNull().default("yellow"),
  isPinned: boolean("isPinned").notNull().default(true),
  createdAt: timestamp("createdAt", { withTimezone: true }).notNull().defaultNow(),
});

export const systemConfig = pgTable("system_config", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
});
