import { db } from "@/db";
import {
  documentReminders,
  garbageSchedules,
  systemConfig,
  timetable,
  workLogs,
} from "@/db/schema";
import { ensureSeedData, getDashboardData } from "@/lib/dashboard-data";
import ical from "node-ical";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

const fractions = new Set(["MIXED", "GLASS", "PLASTIC_METAL", "BIO"]);
const timePattern = /^([01]\d|2[0-3]):[0-5]\d$/;

type AdminBody = Record<string, unknown>;
type CalendarEvent = {
  type?: string;
  start?: Date | string;
  summary?: string;
  rrule?: unknown;
  status?: string;
};

function textValue(value: unknown, maximum = 180) {
  return typeof value === "string" ? value.trim().slice(0, maximum) : "";
}

function validDate(value: unknown) {
  if (typeof value !== "string" || !value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

async function verifyAdminPin(pin: unknown) {
  if (typeof pin !== "string" || pin.length > 32) return false;
  await ensureSeedData();
  const [configured] = await db.select({ value: systemConfig.value })
    .from(systemConfig)
    .where(eq(systemConfig.key, "admin_pin"))
    .limit(1);
  const expectedPin = process.env.ADMIN_PIN || configured?.value || "2468";
  return pin === expectedPin;
}

function normalizeFraction(summary: string) {
  const value = summary.toLocaleLowerCase("pl-PL");
  if (/szkł|glass/.test(value)) return "GLASS";
  if (/plastik|tworzyw|metal|pet|opakowan/.test(value)) return "PLASTIC_METAL";
  if (/bio|odpady zielone|organic/.test(value)) return "BIO";
  if (/zmieszan|niesegreg|mixed|resztkow/.test(value)) return "MIXED";
  return null;
}

function pickupAtNoon(date: Date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 12, 0, 0, 0);
}

async function importCalendar(icsText: string) {
  const parsed = await ical.async.parseICS(icsText);
  const events = Object.values(parsed) as unknown as CalendarEvent[];
  const from = new Date();
  from.setHours(0, 0, 0, 0);
  const until = new Date(from);
  until.setDate(until.getDate() + 366);
  const candidates: Array<{ fraction: string; pickupDate: Date }> = [];

  for (const event of events) {
    if (event.type !== "VEVENT" || event.status === "CANCELLED") continue;
    const fraction = normalizeFraction(event.summary ?? "");
    if (!fraction) continue;
    let dates: Date[] = [];
    if (event.rrule) {
      try {
        const recurring = ical.expandRecurringEvent(event as never, { from, to: until }) as unknown as Array<{ start?: Date }>;
        dates = recurring.map((item) => item.start).filter((date): date is Date => date instanceof Date);
      } catch {
        dates = [];
      }
    }
    if (dates.length === 0 && event.start) {
      const date = event.start instanceof Date ? event.start : new Date(event.start);
      if (!Number.isNaN(date.getTime())) dates = [date];
    }
    for (const date of dates) {
      if (date >= from && date <= until) candidates.push({ fraction, pickupDate: pickupAtNoon(date) });
      if (candidates.length >= 160) break;
    }
    if (candidates.length >= 160) break;
  }

  const existing = await db.select({ fraction: garbageSchedules.fraction, pickupDate: garbageSchedules.pickupDate })
    .from(garbageSchedules);
  const existingKeys = new Set(existing.map(({ fraction, pickupDate }) => {
    const day = new Date(pickupDate);
    return `${fraction}:${day.getFullYear()}-${day.getMonth()}-${day.getDate()}`;
  }));
  const unique = new Map<string, { fraction: string; pickupDate: Date }>();
  for (const item of candidates) {
    const day = item.pickupDate;
    const key = `${item.fraction}:${day.getFullYear()}-${day.getMonth()}-${day.getDate()}`;
    if (!existingKeys.has(key)) unique.set(key, item);
  }
  const additions = [...unique.values()];
  if (additions.length > 0) await db.insert(garbageSchedules).values(additions);
  return { imported: additions.length, detected: candidates.length };
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as AdminBody;
    if (!(await verifyAdminPin(body.pin))) {
      return Response.json({ error: "Nieprawidłowy PIN administratora." }, { status: 401 });
    }
    const action = textValue(body.action, 40);

    if (action === "load") return Response.json(await getDashboardData());

    if (action === "config-save") {
      const city = textValue(body.home_city, 80);
      const wakeWord = textValue(body.wake_word, 48);
      const latitude = Number(body.city_lat);
      const longitude = Number(body.city_lon);
      const children = textValue(body.child_names, 120);
      if (!city || !wakeWord || !children || !Number.isFinite(latitude) || Math.abs(latitude) > 90 || !Number.isFinite(longitude) || Math.abs(longitude) > 180) {
        return Response.json({ error: "Sprawdź nazwę miasta, współrzędne, wake word i imiona domowników." }, { status: 400 });
      }
      const settings = [
        { key: "home_city", value: city },
        { key: "wake_word", value: wakeWord },
        { key: "city_lat", value: String(latitude) },
        { key: "city_lon", value: String(longitude) },
        { key: "child_names", value: children },
      ];
      for (const setting of settings) {
        await db.insert(systemConfig).values(setting)
          .onConflictDoUpdate({ target: systemConfig.key, set: { value: setting.value } });
      }
      return Response.json({ ok: true });
    }

    if (action === "pin-change") {
      if (process.env.ADMIN_PIN) {
        return Response.json({ error: "PIN jest zarządzany przez zmienną środowiskową ADMIN_PIN." }, { status: 409 });
      }
      const nextPin = textValue(body.newPin, 8);
      if (!/^\d{4,8}$/.test(nextPin)) return Response.json({ error: "PIN musi składać się z 4–8 cyfr." }, { status: 400 });
      await db.insert(systemConfig).values({ key: "admin_pin", value: nextPin })
        .onConflictDoUpdate({ target: systemConfig.key, set: { value: nextPin } });
      return Response.json({ ok: true });
    }

    if (action === "lesson-save") {
      const childName = textValue(body.childName, 48);
      const subject = textValue(body.subject, 80);
      const startTime = textValue(body.startTime, 5);
      const endTime = textValue(body.endTime, 5);
      const dayOfWeek = Number(body.dayOfWeek);
      if (!childName || !subject || !timePattern.test(startTime) || !timePattern.test(endTime) || !Number.isInteger(dayOfWeek) || dayOfWeek < 1 || dayOfWeek > 5) {
        return Response.json({ error: "Uzupełnij dziecko, przedmiot, dzień i prawidłowe godziny." }, { status: 400 });
      }
      const values = { childName, subject, startTime, endTime, dayOfWeek, classroom: textValue(body.classroom, 30) || null };
      if (typeof body.id === "string" && body.id) {
        const [lesson] = await db.update(timetable).set(values).where(eq(timetable.id, body.id)).returning();
        if (!lesson) return Response.json({ error: "Nie znaleziono lekcji." }, { status: 404 });
        return Response.json({ ok: true, item: lesson });
      }
      const [lesson] = await db.insert(timetable).values(values).returning();
      return Response.json({ ok: true, item: lesson });
    }

    if (action === "lesson-delete") {
      if (typeof body.id !== "string") return Response.json({ error: "Brak identyfikatora lekcji." }, { status: 400 });
      await db.delete(timetable).where(eq(timetable.id, body.id));
      return Response.json({ ok: true });
    }

    if (action === "waste-save") {
      const fraction = textValue(body.fraction, 24);
      const pickupDate = validDate(body.pickupDate);
      if (!fractions.has(fraction) || !pickupDate) return Response.json({ error: "Wybierz frakcję i prawidłową datę odbioru." }, { status: 400 });
      const date = pickupAtNoon(pickupDate);
      if (typeof body.id === "string" && body.id) {
        const [item] = await db.update(garbageSchedules).set({ fraction, pickupDate: date }).where(eq(garbageSchedules.id, body.id)).returning();
        if (!item) return Response.json({ error: "Nie znaleziono terminu." }, { status: 404 });
        return Response.json({ ok: true, item });
      }
      const [item] = await db.insert(garbageSchedules).values({ fraction, pickupDate: date }).returning();
      return Response.json({ ok: true, item });
    }

    if (action === "waste-delete") {
      if (typeof body.id !== "string") return Response.json({ error: "Brak identyfikatora terminu." }, { status: 400 });
      await db.delete(garbageSchedules).where(eq(garbageSchedules.id, body.id));
      return Response.json({ ok: true });
    }

    if (action === "document-save") {
      const title = textValue(body.title, 100);
      const category = textValue(body.category, 36) || "DOKUMENT";
      const expirationDate = validDate(body.expirationDate);
      if (!title || !expirationDate) return Response.json({ error: "Podaj nazwę dokumentu i datę ważności." }, { status: 400 });
      const values = { title, category, expirationDate };
      if (typeof body.id === "string" && body.id) {
        const [item] = await db.update(documentReminders).set(values).where(eq(documentReminders.id, body.id)).returning();
        if (!item) return Response.json({ error: "Nie znaleziono dokumentu." }, { status: 404 });
        return Response.json({ ok: true, item });
      }
      const [item] = await db.insert(documentReminders).values(values).returning();
      return Response.json({ ok: true, item });
    }

    if (action === "document-delete") {
      if (typeof body.id !== "string") return Response.json({ error: "Brak identyfikatora dokumentu." }, { status: 400 });
      await db.delete(documentReminders).where(eq(documentReminders.id, body.id));
      return Response.json({ ok: true });
    }

    if (action === "worklog-save") {
      const hours = Number(body.hours);
      const date = validDate(body.date);
      if (!Number.isFinite(hours) || hours <= 0 || hours > 24 || !date) return Response.json({ error: "Wpisz poprawną liczbę godzin i datę." }, { status: 400 });
      const values = {
        hours: Math.round(hours * 100) / 100,
        date,
        startTime: timePattern.test(textValue(body.startTime, 5)) ? textValue(body.startTime, 5) : null,
        endTime: timePattern.test(textValue(body.endTime, 5)) ? textValue(body.endTime, 5) : null,
        note: textValue(body.note, 180) || null,
      };
      if (typeof body.id === "string" && body.id) {
        const [item] = await db.update(workLogs).set(values).where(eq(workLogs.id, body.id)).returning();
        if (!item) return Response.json({ error: "Nie znaleziono wpisu pracy." }, { status: 404 });
        return Response.json({ ok: true, item });
      }
      const [item] = await db.insert(workLogs).values(values).returning();
      return Response.json({ ok: true, item });
    }

    if (action === "worklog-delete") {
      if (typeof body.id !== "string") return Response.json({ error: "Brak identyfikatora wpisu pracy." }, { status: 400 });
      await db.delete(workLogs).where(eq(workLogs.id, body.id));
      return Response.json({ ok: true });
    }

    if (action === "ics-import") {
      const content = textValue(body.content, 1_000_000);
      if (!content.includes("BEGIN:VCALENDAR")) return Response.json({ error: "To nie wygląda na plik iCalendar (.ics)." }, { status: 400 });
      try {
        const result = await importCalendar(content);
        return Response.json({ ok: true, ...result });
      } catch (error) {
        console.error("ICS parsing failed", error);
        return Response.json({ error: "Nie udało się odczytać kalendarza ICS." }, { status: 400 });
      }
    }

    return Response.json({ error: "Nieznana operacja administratora." }, { status: 400 });
  } catch (error) {
    console.error("Admin request failed", error);
    return Response.json({ error: "Wystąpił błąd panelu administracyjnego." }, { status: 500 });
  }
}
