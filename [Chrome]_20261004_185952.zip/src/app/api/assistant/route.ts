import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as { message?: unknown; history?: unknown };
    const message = typeof body.message === "string" ? body.message.trim().slice(0, 1200) : "";
    if (!message) return Response.json({ error: "Wpisz wiadomość do asystenta." }, { status: 400 });

    const apiKey = process.env.OPENROUTER_API_KEY;
    if (!apiKey) {
      return Response.json({
        reply: "Jestem tutaj! Zadania, godziny pracy i notatki możesz dodawać bezpośrednio głosem lub z poziomu kafelków. Aby włączyć swobodną rozmowę AI, dodaj OPENROUTER_API_KEY w ustawieniach środowiska aplikacji.",
        source: "local",
      });
    }

    const history = Array.isArray(body.history)
      ? body.history.slice(-8).flatMap((item) => {
          if (!item || typeof item !== "object") return [];
          const entry = item as { role?: unknown; content?: unknown };
          if ((entry.role !== "user" && entry.role !== "assistant") || typeof entry.content !== "string") return [];
          return [{ role: entry.role, content: entry.content.slice(0, 1200) }];
        })
      : [];

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "HTTP-Referer": process.env.NEXT_PUBLIC_SITE_URL || request.nextUrl.origin,
        "X-Title": "HomeDash AI",
      },
      body: JSON.stringify({
        model: process.env.OPENROUTER_MODEL || "openai/gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: "Jesteś HomeDash AI — ciepłym, zwięzłym asystentem polskiej rodziny. Odpowiadaj po polsku, naturalnie i krótko (najwyżej 3 zdania). Nie twierdź, że wykonałeś czynność w systemie — możesz wyjaśnić, jak ją dodać. Nie wymyślaj aktualnej pogody, terminów wywozu ani danych domowników.",
          },
          ...history,
          { role: "user", content: message },
        ],
        temperature: 0.65,
        max_tokens: 220,
      }),
      signal: AbortSignal.timeout(18000),
    });

    if (!response.ok) {
      console.error("OpenRouter request failed with status", response.status);
      return Response.json({ error: "Asystent AI jest chwilowo niedostępny." }, { status: 502 });
    }
    const data = await response.json();
    const reply = data.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim()) {
      return Response.json({ error: "Asystent nie zwrócił odpowiedzi." }, { status: 502 });
    }
    return Response.json({ reply: reply.trim(), source: "openrouter" });
  } catch (error) {
    console.error("Assistant request failed", error);
    return Response.json({ error: "Nie udało się połączyć z asystentem." }, { status: 500 });
  }
}
